class EventCollection extends ItemCollection {
  
}