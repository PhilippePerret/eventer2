class ProjectCollection extends ItemCollection {
  
}