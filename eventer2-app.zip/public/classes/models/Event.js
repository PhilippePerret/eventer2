class Event extends Item {
  
}