class Texte {

}
