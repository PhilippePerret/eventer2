class EditableText {

}
