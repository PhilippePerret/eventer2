# Eventer - tests à faire

- [x] S’assurer que le style du listing des projets et propre à cet eventer et cet eventer seulement
- [ ] S’assurer que le premier projet (en haut du listing — faire trois projets pour ce test) est bien sélectionné
- [ ] 
