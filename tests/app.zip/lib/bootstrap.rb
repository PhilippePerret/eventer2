require 'json'
require 'fileutils'

module Bootstrap
  DEMO_PROJECT_ID = 'demo'
  DEMO_PROJECT_TITLE = 'Projet de démonstration'

  module_function

  def ensure_initial_data!(data_dir)
    FileUtils.mkdir_p(data_dir)
    FileUtils.mkdir_p(projects_dir(data_dir))
    FileUtils.mkdir_p(demo_dir(data_dir))

    write_json(projects_file(data_dir), [DEMO_PROJECT_ID]) unless File.exist?(projects_file(data_dir))
    write_json(demo_project_file(data_dir), demo_project_data) unless File.exist?(demo_project_file(data_dir))
    write_json(events_file(data_dir), demo_events_data) unless File.exist?(events_file(data_dir))
    write_json(brins_file(data_dir), demo_brins_data) unless File.exist?(brins_file(data_dir))
    write_json(persos_file(data_dir), demo_persos_data) unless File.exist?(persos_file(data_dir))
  end

  def projects_file(data_dir)
    File.join(data_dir, '__projects__.json')
  end

  def projects_dir(data_dir)
    File.join(data_dir, '__projects__')
  end

  def demo_dir(data_dir)
    File.join(projects_dir(data_dir), DEMO_PROJECT_ID)
  end

  def demo_project_file(data_dir)
    File.join(data_dir, "#{DEMO_PROJECT_ID}.json")
  end

  def events_file(data_dir)
    File.join(demo_dir(data_dir), '__events__.json')
  end

  def brins_file(data_dir)
    File.join(demo_dir(data_dir), '__brins__.json')
  end

  def persos_file(data_dir)
    File.join(demo_dir(data_dir), '__persos__.json')
  end

  def demo_project_data
    {
      id: DEMO_PROJECT_ID,
      scale: 'project',
      title: DEMO_PROJECT_TITLE,
      nature: 'roman',
      active: true,
      options: { colorizeEventsWithFirstBrin: true },
      events: ['e1'],
      brins: ['b1'],
      persos: ['p1'],
      evenements: demo_events_data,
      lasts_id: { event: 1, brin: 1, perso: 1 }
    }
  end

  def demo_events_data
    [
      {
        id: 'e1',
        title: 'Premier évènement modifiable',
        text: 'Premier évènement modifiable',
        brins: ['b1'],
        persos: ['p1'],
        type: [],
        nature: [],
        duration: nil,
        file: '',
        state: 1,
        child: false
      }
    ]
  end

  def demo_brins_data
    [
      {
        id: 'b1',
        nom: 'Brin principal modifiable',
        badge: 'PRI',
        color: '#578ddb',
        type: 'mint',
        persos: ['p1'],
        file: ''
      }
    ]
  end

  def demo_persos_data
    [
      {
        id: 'p1',
        badge: 'GD',
        avatar: '🙂',
        pseudo: 'Guide',
        patronyme: 'Guide Démo',
        fonctions: ['ment'],
        file: ''
      }
    ]
  end

  def write_json(path, data)
    FileUtils.mkdir_p(File.dirname(path))
    File.write(path, JSON.pretty_generate(data))
  end
end
