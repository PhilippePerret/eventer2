import { test, expect } from '@playwright/test'
import fs from 'fs'
import path from 'path'

const DATA_FOLDER = path.join(process.cwd(), 'data')

function exists(pathname) {
  return fs.existsSync(pathname)
}

function readJson(pathname) {
  return JSON.parse(fs.readFileSync(pathname, 'utf8'))
}

function expectPathExists(pathname, label) {
  expect(
    exists(pathname),
    `${label} introuvable : ${pathname}`
  ).toBe(true)
}

test('application boots without data folder', async ({ page }) => {
  if (exists(DATA_FOLDER)) {
    fs.rmSync(DATA_FOLDER, { recursive: true, force: true })
  }

  const response = await page.goto('http://localhost:4567')

  expect(
    response,
    'Aucune réponse HTTP reçue pour /'
  ).not.toBeNull()

  expect(
    response.status(),
    `GET / retourne ${response.status()} au lieu de 200`
  ).toBe(200)

  expectPathExists(DATA_FOLDER, 'Dossier data')

  const projectsFile = path.join(DATA_FOLDER, '__projects__.json')
  const projectsFolder = path.join(DATA_FOLDER, '__projects__')
  const demoFolder = path.join(projectsFolder, 'demo')
  const eventsFile = path.join(demoFolder, '__events__.json')
  const brinsFile = path.join(demoFolder, '__brins__.json')
  const persosFile = path.join(demoFolder, '__persos__.json')

  expectPathExists(projectsFile, 'Fichier racine des projets')
  expectPathExists(projectsFolder, 'Dossier racine des projets')
  expectPathExists(demoFolder, 'Dossier du projet demo')
  expectPathExists(eventsFile, 'Fichier events du projet demo')
  expectPathExists(brinsFile, 'Fichier brins du projet demo')
  expectPathExists(persosFile, 'Fichier persos du projet demo')

  const projects = readJson(projectsFile)
  const events = readJson(eventsFile)
  const brins = readJson(brinsFile)
  const persos = readJson(persosFile)

  expect(
    projects,
    `__projects__.json doit contenir ["demo"], reçu : ${JSON.stringify(projects)}`
  ).toEqual(['demo'])

  expect(
    events.length,
    '__events__.json doit contenir au moins un event explicatif'
  ).toBeGreaterThan(0)

  expect(
    brins.length,
    '__brins__.json doit contenir au moins un brin explicatif'
  ).toBeGreaterThan(0)

  expect(
    persos.length,
    '__persos__.json doit contenir au moins un personnage explicatif'
  ).toBeGreaterThan(0)

  await expect(
    page.locator('body'),
    'Le projet démo doit être visible dans l’interface'
  ).toContainText('Projet de démonstration')
})
